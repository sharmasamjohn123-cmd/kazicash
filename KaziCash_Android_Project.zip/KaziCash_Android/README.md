# KaziCash Android

Android wrapper for the KaziCash v2 web prototype.

## Build
Open this project in Android Studio and build `app` -> `assembleDebug`.

The resulting APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

This version is a prototype: OTP, real M-Pesa payments, server accounts, chat and production GPS/backend are not connected yet.
